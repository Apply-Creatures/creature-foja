SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP EXTENSION IF EXISTS plpgsql;
DROP SCHEMA IF EXISTS gtestschema;
CREATE SCHEMA gtestschema;

ALTER SCHEMA gtestschema OWNER TO postgres;

COMMENT ON SCHEMA gtestschema IS 'Forgejo default schema';

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';

SET default_tablespace = '';

SET default_with_oids = false;

CREATE TABLE gtestschema.forgejo_version (
    id bigint NOT NULL,
    version bigint
);

ALTER TABLE gtestschema.forgejo_version OWNER TO postgres;

CREATE SEQUENCE gtestschema.forgejo_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE gtestschema.forgejo_version_id_seq OWNER TO postgres;

ALTER SEQUENCE gtestschema.forgejo_version_id_seq OWNED BY gtestschema.forgejo_version.id;

ALTER TABLE ONLY gtestschema.forgejo_version ALTER COLUMN id SET DEFAULT nextval('gtestschema.forgejo_version_id_seq'::regclass);

INSERT INTO gtestschema.forgejo_version (id, version) VALUES (1, 0);

SELECT pg_catalog.setval('gtestschema.forgejo_version_id_seq', 10000, true);

ALTER TABLE ONLY gtestschema.forgejo_version
    ADD CONSTRAINT forgejo_version_pkey PRIMARY KEY (id);

GRANT ALL ON SCHEMA gtestschema TO PUBLIC;
